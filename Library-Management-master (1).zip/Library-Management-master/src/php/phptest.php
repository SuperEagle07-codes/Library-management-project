<?php
echo "<script>echo hello;</script>";
echo "<script src='./swal.js'></script>  ";
echo "<script >
swal('afsdasf');
</script>  ";
?>
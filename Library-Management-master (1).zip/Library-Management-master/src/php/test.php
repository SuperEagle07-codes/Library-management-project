<?php
echo crypt('pass','helloworld@123');
?>